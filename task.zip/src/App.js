import logo from './logo.svg';
import './App.css';
// import { header } from './My-components/eader';
// import  Header from './My-components/Header.js';
import Header from './My-components/Header';
import Disperse from './My-components/Disperse';
function App() {
  return (
    <div>
    
         <Header></Header>
         <Disperse></Disperse>
    </div>
  );
}

export default App;
